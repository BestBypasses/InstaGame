Do not download and install more than one time or else the game will be generated 2 or more times causing your machine to crash and possibly get damaged from the lag 





Thanks for reading :3 

Contact me at randomdude1345@outlook.com I will respond Between 0-10 business days

Also Contact Our Main Headquarters at 1-800-275-2273